# SafeStep — App Store Connect Submission Brief

**Prepared for:** Apple App Store Connect setup

**Important:** This document prepares the submission but does not create or submit an App Store Connect record. The Apple Account Holder, Admin, or App Manager must confirm account-specific values and complete the questionnaires in App Store Connect.

## App identity

| Field | Prepared value | Action |
|---|---|---|
| App name | SafeStep | Use as the localized App Store name; Apple allows 2–30 characters. |
| Subtitle | Safer routes. More confidence. | Confirm within Apple’s 30-character subtitle limit. |
| Primary language | English (U.S.) | Confirm the storefront language used for the initial metadata. |
| Bundle ID | `com.app.safestepexpo` | Must match the uploaded iOS build exactly. |
| Expo slug | `safestep-expo` | Internal Expo identifier; not the App Store SKU. |
| Version | `1.0.0` | Matches `app.config.ts`. |
| Build number | `1` | Matches `app.config.ts`; increment for every later upload. |
| Suggested SKU | `SAFESTEP-IOS-001` | Must be unique in the Apple developer account; confirm before creating the record. |
| Category | Navigation | Confirm against Apple’s available category list; Safety or Lifestyle may be a secondary category if appropriate. |
| Support URL | `https://safestep-j73yxq87.manus.space` | Use only if the published page contains clear SafeStep support/contact guidance. |
| Privacy Policy URL | **Required — not yet supplied** | Do not enter the support URL unless it actually serves a privacy policy. |

## Store metadata — English (U.S.)

### Promotional text

Plan a calmer journey home with route context, GPS confidence, and private on-device trip history.

### Description

SafeStep helps you plan and review a more confident journey home. Enter a destination, compare route context, and make an informed choice using signals such as lighting, walking conditions, and community information.

During a trip, SafeStep helps you stay oriented with route progress, GPS-quality feedback, meaningful spoken cues, and clear recovery states when location confidence changes. The app can also provide an AR route preview on supported development builds, while camera imagery remains on the device.

SafeStep is designed with privacy in mind. Trip notes, route reviews, and local safety evidence are designed for on-device use, and shared arrival updates are coordinate-free. Optional trusted-contact features help you choose how to communicate trip status.

SafeStep is a navigation aid, not an emergency service. Always use your judgment, follow local laws, and contact emergency services when immediate help is needed.

### Keywords

safe routes,walking safety,navigation,route planner,GPS confidence,trip history,AR guidance

### What’s New — version 1.0.0

Welcome to SafeStep. Plan a route, review local context, follow progress with confidence feedback, and keep your trip history private on your device.

## Suggested localizations

Create App Store metadata localizations for Spanish and French after the English record is accepted. The in-app interface already supports English, Spanish, and French, but App Store metadata must be entered separately from binary localization.

| Language | Store name | Subtitle |
|---|---|---|
| Spanish | SafeStep | Rutas más seguras, más confianza |
| French | SafeStep | Des trajets plus sûrs |

Translate the description, keywords, promotional text, and What’s New text with a native-quality review before publishing.

## Privacy questionnaire draft — confirm against actual release behavior

The codebase uses location, camera, optional contacts, local persistence, secure session storage, and audio-related capabilities. The following is a review draft, not a declaration to submit without confirmation.

| App capability | Likely App Store treatment | Draft disclosure |
|---|---|---|
| Location | Location data | Used for navigation and route confidence; confirm whether any location leaves the device in the release build. |
| Camera | Sensitive info / user content depending on Apple’s questionnaire wording | Used for AR guidance; confirm that camera frames remain on-device and are not uploaded. |
| Contacts | Contacts | Optional trusted-contact selection; confirm whether contact data is stored, shared, or only used for a system share flow. |
| Diagnostics | Diagnostics | Confirm whether any crash, performance, or analytics SDK collects data. |
| Account information | Contact info / identifiers if enabled | Confirm whether authentication is reachable in the submitted build and whether account data is collected. |
| Audio | Not necessarily collected | Confirm whether microphone recording is reachable. Do not claim microphone collection merely because a permission string exists. |

The App Privacy section requires a privacy policy URL for iOS and accurate answers covering both the app and any third-party SDKs. The final answers must be based on the exact release binary and data flows.

## Age rating and content rights draft

SafeStep is a utility/navigation product. Review the questionnaire with these likely answers, then confirm each response in App Store Connect:

| Area | Draft position |
|---|---|
| Mature or objectionable content | None intentionally provided. |
| User-generated content | No public community posting is intended; local signal reports are user-entered and device-local. Confirm the submitted build. |
| Gambling, contests, or simulated gambling | None. |
| Medical or treatment information | None; SafeStep is not a medical or emergency service. |
| Violence, horror, profanity, sexual content, drugs, or weapons | None intentionally provided. |
| Content rights | Confirm that all maps, icons, illustrations, audio, trademarks, and third-party assets are licensed or original. |

Do not promise a specific age rating until Apple’s current questionnaire has been completed.

## Pricing and availability

Recommended initial release configuration: **Free**, available in all intended storefront regions, with any paid SafeStep Plus functionality configured through Apple’s In-App Purchase and subscription system rather than external payment flows. Confirm tax, banking, agreements, regional availability, and whether the Plus preview is enabled in the submitted binary before selecting a price.

## Visual assets

The project contains a 1024×1024 icon and matching splash/favicon/adaptive assets. App Store screenshots are separate from app icons. The prepared screenshot set uses real captured SafeStep screens and is placed under `app-store-connect/screenshots/iphone-6.9/` at Apple’s 6.9-inch portrait dimensions. iPad screenshots still require capture from an iPad or iPad simulator if iPad support remains enabled in the submitted build.

## Apple-account actions still required

1. Create the App Store Connect app record using the confirmed SKU, primary language, bundle ID, and name.
2. Add the privacy policy URL and complete the App Privacy questionnaire based on the release build.
3. Complete content rights and the age-rating questionnaire.
4. Select price, tax category, and regional availability.
5. Upload the EAS-built iOS archive, then attach the build to the version record.
6. Upload the iPhone screenshots and add iPad screenshots if the app is distributed for iPad.
7. Complete App Review contact information, demo-account instructions if applicable, and review notes explaining location, camera, and optional contacts behavior.
8. Submit only after physical-device testing confirms English, Spanish, French, permission denial, offline mode, reduced motion, and recovery states.

## Official references

[1]: https://developer.apple.com/help/app-store-connect/reference/app-information/app-information/ "Apple App Store Connect — App information"
[2]: https://developer.apple.com/help/app-store-connect/reference/app-information/screenshot-specifications/ "Apple App Store Connect — Screenshot specifications"
[3]: https://developer.apple.com/help/app-store-connect/manage-app-information/localize-app-information/ "Apple App Store Connect — Localize app information"
[4]: https://developer.apple.com/help/app-store-connect/manage-app-information/manage-app-privacy/ "Apple App Store Connect — Manage app privacy"
